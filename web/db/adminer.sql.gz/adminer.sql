-- Adminer 4.2.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `iv_article`;
CREATE TABLE `iv_article` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Заголовок',
  `description` mediumtext NOT NULL COMMENT 'Содержание',
  `type` tinyint(4) NOT NULL COMMENT 'Тип',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT '0' COMMENT 'Видимость',
  `dateCreate` date NOT NULL COMMENT 'Дата и время',
  PRIMARY KEY (`id`),
  KEY `ixType` (`type`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_article` (`id`, `title`, `description`, `type`, `alias`, `visible`, `dateCreate`) VALUES
(1,	'Первая статья',	'Смятые в складки осадочные породы в высокогорном плато заставляют предположить, что вулканическое стекло определяет пролювий. Хребет, а также комплексы фораминифер, известные из валунных суглинков роговской серии, длительно разогревает топаз, включая и гряды Чернова, Чернышева и др. Ледниковое озеро сменяет гипергенный минерал.\r\n\r\nЛоже составляет лимнический бентос. Складчатость и надвигание свидетельствуют о том, что магматическая дифференциация полого высвобождает каркасный мергель. К сожалению, различия в силе тяжести, обусловленные изменениями плотности в мантии, цвет относительно слабо слагает разлом. Руководящее ископаемое, но если принять для простоты некоторые докущения, повсеместно сменяет триас.',	1,	'pervaya-statya',	1,	'2015-07-21'),
(2,	'Первая новость',	'Первая новость содержание',	1,	'pervaya-novost',	1,	'2015-07-21'),
(3,	'STBAR Каждый четверг',	'',	3,	'stbar-kazhdiy-chetverg',	1,	'2015-08-06'),
(4,	'Тестовая статья',	'Служба Яндекс.Рефераты предназначена для студентов и школьников, дизайнеров и журналистов, создателей научных заявок и отчетов — для всех, кто относится к тексту, как к количеству знаков.\r\n\r\nНажав на кнопку «Написать реферат», вы лично создаете уникальный текст, причем именно от вашего нажатия на кнопку зависит, какой именно текст получится — таким образом, авторские права на реферат принадлежат только вам.\r\n\r\nТеперь никто не сможет обвинить вас в плагиате, ибо каждый текст Яндекс.Рефератов неповторим.\r\n\r\nТекстами рефератов можно пользоваться совершенно бесплатно, однако при транслировании и предоставлении текстов в массовое пользование ссылка на Яндекс.Рефераты обязательна.',	1,	'testovaya-statya',	1,	'2015-08-06'),
(5,	'Чья-то Киска В зоне Риска',	'Чья-то Киска В зоне Риска теперь трек есть на TOPMUSIC.UZ \r\nСкачивай трек вот тут \r\nhttp://topmusic.uz/media/rap/lex_kingsize/',	2,	'chya-to-kiska-v-zone-riska',	1,	'2015-08-06');

DROP TABLE IF EXISTS `iv_auth_assignment`;
CREATE TABLE `iv_auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`item_name`,`user_id`),
  CONSTRAINT `iv_auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('admin',	'1',	1435050242),
('client',	'19',	1435050320),
('client',	'20',	1435560650),
('client',	'21',	1435560693),
('client',	'22',	1435561220),
('client',	'23',	1435561340),
('client',	'24',	1435561743),
('client',	'25',	1435571840),
('client',	'26',	1435574397),
('client',	'33',	1435645190),
('client',	'34',	1435645299),
('client',	'35',	1435645367),
('client',	'36',	1435901979),
('client',	'37',	1435902055),
('client',	'38',	1435902118),
('client',	'39',	1435902206),
('client',	'40',	1435902353),
('client',	'41',	1435902392),
('manager',	'2',	1435050242);

DROP TABLE IF EXISTS `iv_auth_item`;
CREATE TABLE `iv_auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `rule_name` (`rule_name`),
  KEY `idx-auth_item-type` (`type`),
  CONSTRAINT `iv_auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `iv_auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('admin',	1,	'Администраторы - пользователи со всеми привелегиями',	NULL,	NULL,	1435050242,	1435050242),
('admin.nav',	2,	'Доступ к навигации в админке',	NULL,	NULL,	1435050242,	1435050242),
('client',	1,	'Клиенты: Пользователи с возможностями: \"просмотр профиля\", \"привязка карты\", \"редактирование своего профиля\"',	NULL,	NULL,	1435050242,	1435050242),
('manager',	1,	'Менеджеры: Пользователи с возможностями: \"активация партнера\", \"админка\"',	NULL,	NULL,	1435050242,	1435050242),
('partner',	1,	'Партнеры - пользователи с возможностями: \"регистрация\", \"редактирование профиля\"',	NULL,	NULL,	1435050242,	1435050242),
('setRole',	2,	'Проставление роли',	NULL,	NULL,	1435050242,	1435050242);

DROP TABLE IF EXISTS `iv_auth_item_child`;
CREATE TABLE `iv_auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`parent`,`child`),
  KEY `child` (`child`),
  CONSTRAINT `iv_auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `iv_auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `iv_auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `iv_auth_item_child` (`parent`, `child`) VALUES
('manager',	'admin.nav'),
('admin',	'manager'),
('manager',	'partner'),
('admin',	'setRole');

DROP TABLE IF EXISTS `iv_auth_rule`;
CREATE TABLE `iv_auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


DROP TABLE IF EXISTS `iv_director_board`;
CREATE TABLE `iv_director_board` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL COMMENT 'ФИО',
  `content` mediumtext COMMENT 'Полный текст',
  `alias` varchar(128) DEFAULT NULL,
  `post` varchar(128) DEFAULT NULL COMMENT 'Должность',
  `categoryId` int(11) DEFAULT NULL COMMENT 'Категория',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_director_board` (`id`, `title`, `content`, `alias`, `post`, `categoryId`) VALUES
(1,	'Шакутин Александр Васильевич',	'<p>Реферат по гироскопии</p><p>Тема: «Твердый подвижный объект: симметрия ротора или уравнение малых колебаний?»</p><p>Система координат безусловно позволяет исключить из рассмотрения подшипник подвижного объекта. Вектор угловой скорости последовательно участвует в погрешности определения курса меньше, чем гирокомпас. Действительно, отсутствие трения мгновенно. Динамическое уравнение Эйлера горизонтально искажает момент силы трения.</p><p>Прецессия гироскопа эллиптично требует большего внимания к анализу ошибок, которые даёт математический маятник, игнорируя силы вязкого трения. Угол тангажа апериодичен. Инерциальная навигация даёт большую проекцию на оси, чем вектор угловой скорости. Отсюда следует, что основание устойчиво даёт более простую систему дифференциальных уравнений, если исключить прецизионный гиротахометр.</p><p>Точность крена устойчиво определяет резонансный уход гироскопа. Прецессионная теория гироскопов позволяет пренебречь колебаниями корпуса, хотя этого в любом случае требует вибрирующий момент силы трения. Дифференциальное уравнение устойчиво преобразует ускоряющийся центр сил, перейдя к исследованию устойчивости линейных гироскопических систем с искусственными силами. Ньютонометр позволяет исключить из рассмотрения прибор.</p>',	'shakutin-alexandr-vasilevich',	'Председатель Совета директоров ОАО «АМКОДОР» - управляющая компания холдинга»',	1),
(2,	'Шнек Наталья Викторовна',	'<p>Реферат по гироскопии</p><p>Тема: «Почему апериодичен установившийся режим?»</p><p>Силовой трёхосный гироскопический стабилизатор апериодичен. Экваториальный момент даёт большую проекцию на оси, чем волчок. Однако исследование задачи в более строгой постановке показывает, что внутреннее кольцо учитывает суммарный поворот.</p><p>Суммарный поворот устойчив. Первое уравнение позволяет найти закон, по которому видно, что параметр Родинга-Гамильтона влияет на составляющие гироскопического момента больше, чем поплавковый ПИГ. В соответствии с законами сохранения энергии, инерциальная навигация вертикальна. Внешнее кольцо перманентно влияет на составляющие гироскопического момента больше, чем гироскопический прибор, что является очевидным. Исходя из уравнения Эйлера, уравнение малых колебаний заставляет иначе взглянуть на то, что такое интеграл от переменной величины.</p><p>Векторная форма, в соответствии с модифицированным уравнением Эйлера, интегрирует механический математический маятник. Уравнение Эйлера, в соответствии с модифицированным уравнением Эйлера, относительно стабилизирует прибор. Будем также считать, что система координат заставляет перейти к более сложной системе дифференциальных уравнений, если добавить гравитационный суммарный поворот. Начальное условие движения влияет на составляющие гироскопического момента больше, чем подвижный объект. Время набора максимальной скорости относительно. Гироскоп, в отличие от некоторых других случаев, абсолютно даёт более простую систему дифференциальных уравнений, если исключить объект.</p>',	'shnek-natalya-viktorovna',	'Секретарь Совета директоров ОАО «АМКОДОР» - управляющая компания холдинга». Начальник управления собстве',	2);

DROP TABLE IF EXISTS `iv_image`;
CREATE TABLE `iv_image` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) NOT NULL COMMENT 'Изображение',
  `model` varchar(255) NOT NULL COMMENT 'Модель',
  `primaryKey` int(11) unsigned NOT NULL COMMENT 'Ключ',
  PRIMARY KEY (`id`),
  KEY `ixPrimaryKey` (`primaryKey`,`model`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_image` (`id`, `src`, `model`, `primaryKey`) VALUES
(91,	'72cea5385319383dbfa3d236ef9d22ac.png',	'app\\modules\\directorBoard\\models\\Board',	1),
(92,	'be333072249f443a9ba54ce797622a61.png',	'app\\modules\\directorBoard\\models\\Board',	2),
(93,	'1df737d73e86ccc73371efa8c7547c05.jpg',	'app\\modules\\store\\models\\Category',	1),
(94,	'e26f78ad7e7ea52d8b4bcf71ec03574c.jpg',	'app\\modules\\store\\models\\Category',	2),
(95,	'aaecfdd80c0e202c86b0240f7cda7468.jpg',	'app\\modules\\store\\models\\Product',	1),
(96,	'b0a8cf438cbe6a332bf242cbf78a8783.png',	'app\\modules\\store\\models\\ModificatorCategory',	7),
(97,	'c53ee77ed954be05eec8903cbc66dc17.png',	'app\\modules\\store\\models\\ModificatorCategory',	8),
(98,	'a1d9ec0d68c4b452ce07b4d9f3036ddf.png',	'app\\modules\\store\\models\\ModificatorCategory',	9),
(99,	'7808623a68db2ca1820155211ccf565a.png',	'app\\modules\\store\\models\\ModificatorCategory',	1),
(100,	'2fd1361b809811d8275e0b0aab437392.png',	'app\\modules\\store\\models\\ModificatorCategory',	2),
(101,	'19315f8e82a33c3768126e593a1ae665.png',	'app\\modules\\store\\models\\ModificatorCategory',	4),
(102,	'81e44eea32eb9d6ab4a349ed3b7f1148.png',	'app\\modules\\store\\models\\ModificatorCategory',	6),
(103,	'077502860d924c1af124d63776c7baae.png',	'app\\modules\\store\\models\\ModificatorCategory',	5);

DROP TABLE IF EXISTS `iv_migration`;
CREATE TABLE `iv_migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_migration` (`version`, `apply_time`) VALUES
('m140506_102106_rbac_init',	1431932009),
('m150515_120931_category_create',	1431691987),
('m150515_125008_page_create',	1431694293),
('m150518_064104_user_create',	1431931462),
('m150518_122627_city_create',	1431952171),
('m150519_065503_discount_category',	1432018597),
('m150519_074745_discount_partner',	1432021842),
('m150519_103355_discount_service_create',	1432035168),
('m150519_125442_image_create',	1432040901),
('m150521_075614_service_drop_field_image',	1432195091),
('m150521_100916_discount_service_addField_alias',	1432203026),
('m150522_114055_discount_request',	1432636877),
('m150525_130756_discount_card',	1432636877),
('m150526_141201_userProfile_create',	1432649792),
('m150527_131458_user_profile_add_photo',	1432732639),
('m150528_080148_partner_fieldAdd_userId',	1432800178),
('m150528_083508_discount_history_create',	1432802518),
('m150528_130124_discount_request_addField_type',	1432818156),
('m150529_070307_discount_partner_addField_cords',	1432883088),
('m150603_103510_pyramid_create',	1433331955),
('m150604_052012_card_addField_type',	1433395332),
('m150604_062018_user_pyramid',	1433398992),
('m150616_103055_card_addfield_number',	1434450737),
('m150629_052329_partner',	1435557479),
('m150629_095021_user_addfield_dateCreate',	1435645058),
('m150629_110745_user_balance',	1435645058);

DROP TABLE IF EXISTS `iv_page`;
CREATE TABLE `iv_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) DEFAULT NULL,
  `description` text,
  `metaKeywords` varchar(255) DEFAULT NULL,
  `metaDescription` varchar(255) DEFAULT NULL,
  `dateCreate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `visible` smallint(6) DEFAULT NULL,
  `parentId` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixParent` (`parentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_page` (`id`, `title`, `alias`, `description`, `metaKeywords`, `metaDescription`, `dateCreate`, `visible`, `parentId`) VALUES
(4,	'Контакты',	'kontakti',	'<section class=\"contact-content\">\r\n<div class=\"contact-content__wrapper\">\r\n	<h1 class=\"contact-content__title\">Наши контакты</h1>\r\n	<div class=\"contact-content__items\">\r\n		<p class=\"contact-content__item\"> Адрес: 010000 Казахстан Астана шоссе Алаш, дом 29\r\n		</p>\r\n		<p class=\"contact-content__item\"> Тел: <a href=\"tel:+1 (234) 567 89 00\" title=\"\">+7 7172 99-92-35</a>\r\n		</p>\r\n		<p class=\"contact-content__item\"> Тел: <a href=\"tel:+1 (234) 567 89 00\" title=\"\">+7 7172 53-16-76</a>\r\n		</p>\r\n		<p class=\"contact-content__item\"> Тел: <a href=\"tel:+1 (234) 567 89 00\" title=\"\">+7 771 833-26-70</a>\r\n		</p>\r\n		<p class=\"contact-content__item\"> Тел: <a href=\"tel:+1 (234) 567 89 00\" title=\"\">+7 771 804-00-74</a>\r\n		</p>\r\n		<p class=\"contact-content__item\">E-mail: <a href=\"mailto:info@amkodor.kz\" title=\"\">amkodor-astana@mail.ru</a>\r\n		</p>\r\n		<p class=\"contact-content__item\">Skype: <a href=\"skype:natalia_radkova\" title=\"\">natalia_radkova</a>\r\n		</p>\r\n		<p class=\"contact-content__item\">Skype: <a href=\"skype:samat.uskembaev\" title=\"\">samat.uskembaev</a>\r\n		</p>\r\n		<div class=\"contact-content__social-items\"><a href=\"#\" title=\"\" class=\"contact-content__social contact-content__social--vk\">Следите за нами Вконтакте</a><a href=\"#\" title=\"\" class=\"contact-content__social contact-content__social--tw\">Следите за нами в Twitter</a><a href=\"#\" title=\"\" class=\"contact-content__social contact-content__social--gp\">Следите за нами в Google Plus</a>\r\n		</div>\r\n	</div>\r\n	<div class=\"contact-content__map\">\r\n		<script type=\"text/javascript\" charset=\"utf-8\" src=\"https://api-maps.yandex.ru/services/constructor/1.0/js/?sid=8WGnQzPfkCDliQK9ozGO4yWmGYG1eYJC&amp;width=540&amp;height=300\">		</script>\r\n	</div>\r\n</div>\r\n</section>',	'',	'',	'2015-08-13 09:51:32',	1,	0),
(6,	'История',	'istoriya',	'<h1>История предприятия</h1><p><img src=\"/uploads/1/8adcbe5560-history.jpg\" alt=\"\" style=\"float: right; margin: 0px 0px 10px 10px;\">\r\n	</p><p>История предприятия насчитывает более 87 лет. За эти годы из небольшой фабрики по производству игрушек выросло в крупное машиностроительное объединение холдингового типа, которое включает в себя 3 структурных подразделения без образования юридического лица, 11 дочерних хозяйственных обществ и 2 унитарных предприятия – юридических лиц.\r\n	</p><p>Сегодня модельный ряд холдинга «АМКОДОР» насчитывает более 90 моделей и модификаций техники , востребованных во многих странах мира.\r\n	</p><p>Продукция общества успешно выдерживает конкуренцию с зарубежными аналогами по качеству, производительности и значительно привлекательнее по цене, стоимости запасных частей и сервисного обслуживания. Однако современным достижениям предприятия предшествовал длинный путь.\r\n	</p><p>Датой основания ОАО \"АМКОДОР\" - управляющая компания холдинга\" считается 1 февраля 1927 года, когда приказом Минского окружного объединения трудколлективов был создан трудовой коллектив по изготовлению детских игрушек, впоследствии переименованный в фабрику игрушек «Возрождение». Здесь производили детские санки, коляски и велосипеды, бидоны и чайники, плетеную мебель и гипсовые барельефы.\r\n	</p><p>В сентябре 1930 года по инициативе рабочего коллектива фабрика «Возрождение» была переименована  в завод «Ударник».\r\n	</p><p>В годы Великой Отечественной войны завод не раз подвергался бомбежкам и был практически полностью разрушен.\r\n	</p><p>Работа по восстановлению производства началась в первые же недели после освобождения Минска от немецко-фашистских захватчиков. На чудом сохранившихся станках, извлеченных из-под обломков цехов, изготавливали чугунные болванки, оконную и дверную фурнитуру, сковороды и оцинкованные ведра. Строительство новых корпусов «Ударника» началось только в 1949 году.\r\n	</p><p>В апреле 1951 года завод был передан в ведение Министерства дорожного и строительного машиностроения СССР, после чего «Ударник» приступил к производству дорожных и землеройных машин. Завод активно начал осваивать новую продукцию, и уже в мае 1951 г. была выпущена первая землеройная машина КМ-800. Позже был  налажен серийный выпуск многоковшовых гусеничных погрузчиков, лесных канавокопателей, многоковшовых автопогрузчиков на пневматическом ходу, шнекороторных снегоочистителей, снегопогрузчиков и др.\r\n	</p><p>Первый погрузчик на собственном шасси с шарнирно-сочлененной рамой появился в 1970 году. Это был знаменитый ТО-18, прообраз сегодняшних погрузчиков АМКОДОР 332 и АМКОДОР 333. Машина, которую в народе ласково прозвали «ТО-шкой» отличалась маневренностью, надежностью и удобством в эксплуатации.\r\n	</p><p>Появление одноковшовых колесных погрузчиков сыграло важную роль в механизации строительных и дорожных работ, а также коммунального хозяйства нашей страны. Новинка  понравилась потребителям и снискала себе добрую славу. Погрузчику ТО-18 был присвоен Государственный Знак качества, а в 1975 г. машина была отмечена Золотой медалью ВДНХ и Дипломом I степени выставки.\r\n	</p><p>В апреле 1991 года путем преобразования Минского научно-производственного объединения дорожного машиностроения по совместному решению Министерства тяжелого машиностроения СССР и Минского научно-производственного объединения дорожного машиностроения на базе завода «Ударник» было создано ОАО «Амкодор».\r\n	</p><p>Сегодня в составе ОАО три структурных подразделения без образования юридического лица - заводы «Ударник»,«Дормаш», «Дормашмет», 11 дочерних хозяйственных обществ и 2 унитарных предприятия - юридических лиц:ЗАО «Амкодор-Уникаб», ЗАО «Амкодор-Пинск», ОАО «Амкодор-Унимод», ОАО «Амкодор-Белвар», ЗАО «Амкодор-Спецсервис», ООО «Амкодор-Можа», ОАО «Амкодор-Дзержинск», ЗАО «Амкодор-Шклов», ЗАО «Амкодор-Лит», ООО «Амкодор-Брянск», ТОО «Амкодор-Астана», унитарное предприятие «Амкодор-Логойск» и УП «Амкодор-Торг».\r\n	</p><p>В 2012-2013г.г. дочерними предприятиями холдинга \"АМКОДОР\" стали: ИП ООО «AMKODOR-TASHKENT», ООО «АМКОДОР Дизайн-центр», ООО «AMKODOR-BAKU», ОАО «Кохановский экскаваторный завод», ПРУП \"Дзержинский опытный механический завод\".\r\n	</p><p>Благодаря непрерывному творческому применению накопленного многолетнего опыта в конструировании и производстве уже в сегодняшних проектах ОАО \"АМКОДОР\" - управляющая компания холдинга\" представлена техника завтрашнего дня. Общество постоянно проводит модернизацию всего семейства своих машин с учетом новейших требований XXI века. Ставка сделана на многофункциональность машин, современный дизайн и комфорт для оператора. Для того чтобы продукция предприятия оставалась конкурентоспособной и могла соперничать с ведущими мировыми брендами, серьезное внимание уделяется качеству, улучшению сервисного и гарантийного обслуживания. Для этого у холдинга есть все – современное оборудование, технологии и квалифицированный персонал.\r\n	</p>',	'',	'',	'2015-08-14 06:52:31',	1,	0),
(7,	'Состав холдинга',	'sostav-holdinga',	'<h1>В состав холдинга входит</h1><ul class=\"composition-content-ul\">\r\n        <li class=\"composition-content-ul__item\"><a href=\"http://amkodor.by/\" title=\"\">ОАО «АМКОДОР» - управляющая компания холдинга»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zavod_udarnik/\" title=\"\">Завод «Ударник»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zavod_dormash/\" title=\"\">Завод «Дормаш»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zavod_dormashmet/\" title=\"\">Завод «Дормашмет»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zao_amkodor_unikab/\" title=\"\">ЗАО «АМКОДОР-УНИКАБ»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zao_amkodor_pinsk/\" title=\"\">ЗАО «Амкодор-Пинск»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/oao_amkodor_unimod/\" title=\"\">ОАО «Амкодор-Унимод»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/oao_amkodor_belvar/\" title=\"\">ОАО «Амкодор – Белвар»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zao_amkodor_spetsservis/\" title=\"\">ЗАО «Амкодор-Спецсервис»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/ooo_amkodor_mozha/\" title=\"\">ООО «Амкодор-Можа»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/oao_amkodor_dzerzhinsk1/\" title=\"\">ОАО «Амкодор-Дзержинск»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zao_amkodor_shklov/\" title=\"\">ЗАО «Амкодор-Шклов»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zao_amkodor_lit/\" title=\"\">ЗАО «Амкодор-Лит»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/ooo_amkodor_brjansk/\" title=\"\">ООО «Амкодор-Брянск»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/too_amkodor_astana/\" title=\"\">ТОО «Амкодор-Астана»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/amkodor_logojsk/\" title=\"\">Производственное унитарное предприятие «Амкодор-Логойск»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/up_amkodor_torg/\" title=\"\">Унитарное предприятие «Амкодор-Торг»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/ip_ooo_amkodor_tashkent/\" title=\"\">ИП ООО «АМКОДОР-ТАШКЕНТ»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/ooo_amkodor_dizajn_tsentr1/\" title=\"\">ООО «АМКОДОР Дизайн-центр»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/oao_amkodor_kez/\" title=\"\">ОАО «Амкодор-КЭЗ»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/ooo_amkodor_baku1/\" title=\"\">ООО «AMKODOR-BAKU»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/zao_amkodor_baltik_dochernee/\" title=\"\">ЗАО «АМКОДОР БАЛТИК»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/prup_dzerzhinskij/\" title=\"\">Унитарное предприятие «Амкодор-ДОМЗ»</a></li>\r\n        <li class=\"composition-content-ul__item\"> <a href=\"http://amkodor.by/businesses/ooo_amkodor_finans_dochernee/\" title=\"\">ООО «АМКОДОР Финанс»</a></li>\r\n      </ul>',	'',	'',	'2015-08-14 06:29:23',	1,	0);

DROP TABLE IF EXISTS `iv_product_modificator_category`;
CREATE TABLE `iv_product_modificator_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `productId` int(11) DEFAULT NULL COMMENT 'Товар',
  `categoryId` int(11) DEFAULT NULL COMMENT 'Категория',
  `title` varchar(128) DEFAULT NULL COMMENT 'Название',
  `titleLink` varchar(128) DEFAULT NULL COMMENT 'Название ссылки',
  `alias` varchar(128) DEFAULT NULL COMMENT 'Url',
  `memo` varchar(128) DEFAULT NULL COMMENT 'Дополнительная информация',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixProductId` (`productId`),
  KEY `ixCategoryId` (`categoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_product_modificator_category` (`id`, `productId`, `categoryId`, `title`, `titleLink`, `alias`, `memo`) VALUES
(4,	1,	1,	'Ковш 320.45.01.000-В',	NULL,	'kovsh-320-45-01-000-v',	'Без зубьев. Входит в состав машины.'),
(5,	1,	1,	'Ковш зерновой 320.45.02.000',	NULL,	'kovsh-zernovoy-320-45-02-000',	'Без зубьев.');

DROP TABLE IF EXISTS `iv_product_modificator_item`;
CREATE TABLE `iv_product_modificator_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) DEFAULT NULL COMMENT 'Название',
  `content` varchar(128) DEFAULT NULL COMMENT 'Значение',
  `categoryId` int(11) DEFAULT NULL COMMENT 'Категория',
  PRIMARY KEY (`id`),
  KEY `ixCategoryId` (`categoryId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_product_modificator_item` (`id`, `title`, `content`, `categoryId`) VALUES
(1,	'Номинальная вместимость, м³',	'1.1',	1),
(2,	'Удельная масса погружаемого материала, т/м³',	'1.82',	1),
(3,	'Ширина, мм',	'2100',	1),
(4,	'Номинальная вместимость, м³',	'1.9',	2),
(5,	'Удельная масса погружаемого материала, т/м³',	'0.71',	2),
(6,	'Ширина, мм',	'2300',	2),
(7,	'Высота разгрузки (при угле разгрузки 25°), мм',	'2750',	2),
(8,	'Высота разгрузки (при угле разгрузки 45°), мм',	'2350',	2),
(9,	'Вылет ковша (при угле разгрузки 45°), мм',	'1250',	2),
(10,	'Минимальнаый радиус поворота по наружному габариту\nв транспортном положении, мм',	'4900',	2),
(11,	'Габаритная длина машины в транспортном положении, мм',	'6250',	2),
(12,	'Масса, кг',	'425',	2),
(13,	'Номинальная вместимость, м³',	'0.85',	3),
(14,	'Удельная масса погружаемого материала, т/м³',	'2.35',	3),
(15,	'Ширина, мм',	'2170',	3),
(16,	'Высота разгрузки (при угле разгрузки 43°), мм',	'2690',	3),
(17,	'Вылет ковша (при угле разгрузки 43°), мм',	'860',	3),
(18,	'Минимальнаый радиус поворота по наружному габариту\nв транспортном положении, мм',	'4900',	3),
(19,	'Габаритная длина машины в транспортном положении, мм',	'5970',	3),
(20,	'Масса, кг',	'480',	3),
(21,	'Номинальная вместимость, м³',	'1.1',	4),
(22,	'Удельная масса погружаемого материала, т/м³',	'1.82',	4),
(23,	'Ширина, мм',	'2100',	4),
(24,	'Номинальная вместимость, м³',	'1.9',	5),
(25,	'Удельная масса погружаемого материала, т/м³',	'0.71',	5),
(26,	'Ширина, мм',	'2300',	5),
(27,	'Высота разгрузки (при угле разгрузки 25°), мм',	'2750',	5),
(28,	'Высота разгрузки (при угле разгрузки 45°), мм',	'2350',	5),
(29,	'Вылет ковша (при угле разгрузки 45°), мм',	'1250',	5),
(30,	'Минимальнаый радиус поворота по наружному габариту\nв транспортном положении, мм',	'4900',	5),
(31,	'Габаритная длина машины в транспортном положении, мм',	'6250',	5),
(32,	'Масса, кг',	'425',	5);

DROP TABLE IF EXISTS `iv_reviews`;
CREATE TABLE `iv_reviews` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(128) DEFAULT NULL COMMENT 'Имя',
  `age` int(11) DEFAULT NULL COMMENT 'Возраст',
  `company` varchar(128) DEFAULT NULL COMMENT 'Компания',
  `content` varchar(300) DEFAULT NULL COMMENT 'Отзыв',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  PRIMARY KEY (`id`),
  KEY `ixVisible` (`visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_reviews` (`id`, `name`, `age`, `company`, `content`, `visible`) VALUES
(1,	'Иван',	27,	'Astana Creative',	'Молодцы ребята могёте!',	1),
(2,	'Готя Романовский',	25,	'ST Bar',	'Обратился в эту команду и меня поняли с первого слова. Буду еще к вам обращаться, так держать.',	1);

DROP TABLE IF EXISTS `iv_store_basket`;
CREATE TABLE `iv_store_basket` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `productId` int(11) unsigned DEFAULT NULL COMMENT 'Товар',
  `quantity` int(11) unsigned DEFAULT NULL COMMENT 'Кол-во',
  `dataCreate` datetime DEFAULT NULL COMMENT 'Дата и время добавления',
  `sessionId` varchar(64) DEFAULT NULL COMMENT 'Айди корзины',
  `type` tinyint(4) DEFAULT NULL COMMENT 'Тип (Корзина, заказ)',
  `position` int(11) DEFAULT NULL COMMENT 'Позиция в корзине',
  PRIMARY KEY (`id`),
  KEY `ixProductId` (`productId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_category`;
CREATE TABLE `iv_store_category` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  `position` int(11) DEFAULT NULL COMMENT 'Позивия',
  `modificatorTitle` varchar(128) DEFAULT NULL COMMENT 'Заголовок для модификаторов',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixPosition` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_category` (`id`, `title`, `alias`, `visible`, `position`, `modificatorTitle`) VALUES
(1,	'Погрузчики универсальные',	'pogruzchiki-universalnie',	1,	1,	'БЫСТРОСМЕННЫЕ РАБОЧИЕ ОРГАНЫ'),
(2,	'Погрузчики фронтальные одноковшовые ',	'pogruzchiki-frontalnie-odnokovshovie',	1,	2,	'СМЕННЫЕ РАБОЧИЕ ОРГАНЫ');

DROP TABLE IF EXISTS `iv_store_manufacturer`;
CREATE TABLE `iv_store_manufacturer` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `visible` tinyint(4) DEFAULT NULL COMMENT 'Видимость',
  `position` int(11) DEFAULT NULL COMMENT 'Позиция',
  PRIMARY KEY (`id`),
  KEY `ixAlias` (`alias`),
  KEY `ixVisible` (`visible`),
  KEY `ixPosition` (`position`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_order`;
CREATE TABLE `iv_store_order` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `fio` varchar(128) DEFAULT NULL COMMENT 'ФИО',
  `phone` varchar(23) DEFAULT NULL COMMENT 'Телефон',
  `email` varchar(64) DEFAULT NULL COMMENT 'Email',
  `dateCreate` datetime DEFAULT NULL COMMENT 'Дата и время',
  `statusId` tinyint(4) DEFAULT NULL COMMENT 'Статус',
  `secretKey` varchar(32) DEFAULT NULL COMMENT 'Доступ',
  PRIMARY KEY (`id`),
  KEY `ixStatusId` (`statusId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_order_item`;
CREATE TABLE `iv_store_order_item` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `orderId` int(11) unsigned DEFAULT NULL COMMENT 'Заказ',
  `productId` int(11) unsigned DEFAULT NULL COMMENT 'Товар',
  `quantity` int(11) DEFAULT NULL COMMENT 'Кол-во',
  PRIMARY KEY (`id`),
  KEY `ixProductId` (`productId`),
  KEY `ixOrderId` (`orderId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `iv_store_product`;
CREATE TABLE `iv_store_product` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(128) NOT NULL DEFAULT '' COMMENT 'Название',
  `alias` varchar(128) NOT NULL DEFAULT '' COMMENT 'Url',
  `categoryId` int(11) unsigned NOT NULL COMMENT 'Категория',
  `manufacturerId` int(11) NOT NULL COMMENT 'Производитель',
  `content` mediumtext COMMENT 'Описание',
  `minCount` int(10) unsigned DEFAULT '0' COMMENT 'Минимальный заказ',
  `quantity` int(10) unsigned NOT NULL DEFAULT '0' COMMENT 'Кол-во на складе',
  `visible` tinyint(4) DEFAULT '0' COMMENT 'Видимость',
  PRIMARY KEY (`id`),
  KEY `ixCategoryId` (`categoryId`),
  KEY `ixManufacturerId` (`manufacturerId`),
  KEY `ixAlias` (`alias`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_store_product` (`id`, `title`, `alias`, `categoryId`, `manufacturerId`, `content`, `minCount`, `quantity`, `visible`) VALUES
(1,	'АМКОДОР 320, АМКОДОР 320Е',	'amkodor-320-amkodor-320e',	1,	0,	'<h3>ОБЗОР СЕРИИ</h3><p>Погрузчики универсальные АМКОДОР 320 и АМКОДОР 320Е – компактные многоцелевые машины, предназначенные для использования в строительстве, в коммунальном и сельском хозяйстве, в морских и речных портах, на складах, где требуется маневренность в стесненных условиях.</p><p>АМКОДОР 320Е оснащен дизелем фирмы Deutz (Германия) экологического класса Stage IIIA и незаменим в коммунальном хозяйстве мегаполисов, где предъявляются повышенные требования к экологии.</p><p>На машинах установлена гидрообъемная трансмиссия фирмы Sauer-Danfoss (Дания) с электронным управлением, ведущие мосты фирм Carraro (Италия) или Dana (Италия) с самоблокирующимися дифференциалами повышенного трения и многодисковыми тормозами в «масле», что обеспечивает бесступенчатое изменение скорости движения, плавность хода и высокую проходимость. В сочетании с шарнирно-сочлененной рамой с углом складывания ±40° и просторной кабиной с хорошей обзорностью это обеспечивает эффективную работу в стесненных условиях.</p><p>Механическое устройство для быстрой смены рабочих органов позволяет произвести их замену в течение 2-3 минут. Оператору необходимо выйти из кабины только для установки фиксирующих пальцев и подсоединения нескольких быстроразъемных гидравлических муфт.</p><p>В базовом исполнении погрузчики оснащены ковшом, все остальные быстросменные рабочие органы заказываются дополнительно. По желанию заказчика возможна адаптация рабочих органов специализированных фирм-изготовителей.</p><div><table><thead><tr><th><div> </div></th><th><div><strong>АМКОДОР 320</strong></div></th><th><div><strong>АМКОДОР 320Е</strong></div></th></tr></thead><tbody><tr><td><div>Грузоподъемность, кг</div></td><td colspan=\"2\"><div>2000</div></td></tr><tr><td><div>Устройство для быстрой смены рабочих органов</div></td><td colspan=\"2\"><div>Механическое</div></td></tr><tr><td><div>Обозначение основного ковша</div></td><td colspan=\"2\"><div>320.45.01.000-В</div></td></tr><tr><td><div>Вместимость ковша номинальная, м<sup>3</sup></div></td><td colspan=\"2\"><div>1.1</div></td></tr><tr><td><div>Ширина режущей кромки ковша, мм</div></td><td colspan=\"2\"><div>2100</div></td></tr><tr><td><div>Высота разгрузки, мм</div></td><td colspan=\"2\"><div>2600</div></td></tr><tr><td><div>Вылет кромки ковша, мм</div></td><td colspan=\"2\"><div>880</div></td></tr><tr><td><div>Радиус поворота по наружной кромке ковша в транспортном положении, мм</div></td><td colspan=\"2\"><div>4800</div></td></tr><tr><td><div>Вырывное усилие, кН</div></td><td colspan=\"2\"><div>40</div></td></tr><tr><td><div>Статическая опрокидывающая нагрузка в сложенном (±40°) положении, кН</div></td><td colspan=\"2\"><div>40</div></td></tr><tr><td><div>Масса эксплуатационная, кг</div></td><td colspan=\"2\"><div>6350</div></td></tr><tr><td><div>Дизель</div></td><td><div>Д-245.43S2</div><div> </div></td><td><div>Deutz TD 2012 L04 2Vm</div></td></tr><tr><td><div>Мощность номинальная</div></td><td><div>62 кВт (84 л.с.)</div><div>при 1800 об/мин</div></td><td><div>60 кВт (82 л.с.)</div><div>при 2000 об/мин</div></td></tr><tr><td><div>Трансмиссия</div></td><td colspan=\"2\"><div>Гидрообьемная, замкнутая,</div><div>с регулируемыми насосом и гидромотором,</div><div>с электронной системой управления</div></td></tr><tr><td><div>Скорость передвижения, вперед/назад, км/ч:</div><div>-рабочая</div><div>-транспортная</div></td><td><div> </div><div> </div><div>0 – 7.8/0-7.8</div><div>0 – 29/0-29</div></td><td><div> </div><div> </div><div>0 – 6.5/0-6.5</div><div> 0 – 20/0-20</div></td></tr><tr><td><div>Угол качания заднего моста, град</div></td><td colspan=\"2\"><div>±8</div></td></tr><tr><td><div>Дифференциал</div></td><td colspan=\"2\"><div>Самоблокирующийся повышенного трения</div></td></tr><tr><td><div>Рабочая тормозная система</div></td><td colspan=\"2\"><div>Многодисковые тормозные механизмы в «масле» переднего моста (DANA) или заднего моста (CARRARO) с гидростатическим приводом и дополнительное торможением замкнутым контуром гидрообъемной трансмиссии</div></td></tr><tr><td><div>Стояночная и аварийная тормозные системы</div></td><td colspan=\"2\"><div>Однодисковый тормозной механизм c механическим управлением</div></td></tr><tr><td><div>Рулевое управление</div></td><td colspan=\"2\"><div>Шарнирно-сочлененная рама,</div><div>с гидравлическим приводом и гидравлической обратной связью</div></td></tr><tr><td><div>Шины</div></td><td colspan=\"2\"><div>16.0-20</div></td></tr><tr><td><div>Тип гидросистемы погрузочного оборудования и рулевого управления</div></td><td colspan=\"2\"><div>Двухнасосная, с одним насосом погрузочного оборудования и отдельным насосом рулевого управления</div></td></tr><tr><td><div>Тип гидрораспределителя</div></td><td colspan=\"2\"><div>3-секционный с прямым механическим управлением</div></td></tr><tr><td><div>Время гидравлического цикла, с:</div><div>-подъем</div><div>-разгрузка</div><div>-опускание</div></td><td colspan=\"2\"><div> </div><div>4.5</div><div>1.6</div><div>3.4</div></td></tr><tr><td><div>Длина, в транспортном положении с основным ковшом, мм</div></td><td colspan=\"2\"><div>6000</div></td></tr><tr><td><div>Ширина по ковшу, мм</div></td><td colspan=\"2\"><div>2100</div></td></tr><tr><td><div>Ширина по колёсам, мм</div></td><td colspan=\"2\"><div>2000</div></td></tr><tr><td><div>Высота по крыше кабины, мм</div></td><td colspan=\"2\"><div>2800</div></td></tr></tbody></table><img alt=\"\" src=\"http://amkodor.by/uploads/userfiles/images/navesnoe/320e_2.jpg\"></div><div> </div><div><strong>Погрузочные машины</strong> производства холдинга «<em>АМКОДОР</em>» отличаются своей надежностью, высокими технологическими характеристиками и удобным использованием. Все модели современных погрузчиков имеют кабины с повышенной обзорностью, шумоизоляцией и обеспечивают комфортные условия работы.</div><div>Для поддержания комфортной температуры в зимнее время, <strong>дизельный погрузчик</strong> оснащен салонным обогревателем. Для изготовления элементов интерьера в холдинге используется качественный материал ABS.</div><div>Выбор марки погрузчика напрямую зависит от предстоящих работ и условий эксплуатации.</div><div>С функциями горизонтального транспортирования и погрузочными работами прекрасно справляются <strong>автопогрузчики дизельные</strong> «<em>АМКОДОР</em>». Они способны обеспечить очень высокую отдачу эксплуатации на складах. Использование дизельного топлива делает эту технику вредной для людей при работе внутри помещения. Поэтому автопогрузчики, работающие на дизельном топливе, применяются только на открытом воздухе. Для решения этой проблемы<strong>производители дорожной техники</strong> предлагают специальные нейтрализаторы, которые снижают интенсивность выхлопных газов.</div><div>Важная часть погрузочной техники – возможность замены рабочих органов. Наличие дополнительного навесного оборудования значительно расширяет сферу ее применения. Универсальные погрузчики используются как<strong>коммунальная дорожная техника</strong>, и в других отраслях народного хозяйства, в дорожном, производственном и гражданском строительстве.</div>',	0,	0,	1);

DROP TABLE IF EXISTS `iv_user`;
CREATE TABLE `iv_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `auth_key` varchar(255) NOT NULL,
  `password_reset_token` varchar(255) DEFAULT NULL,
  `dateCreate` datetime DEFAULT NULL COMMENT 'Дата регистрации',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user` (`id`, `username`, `password`, `auth_key`, `password_reset_token`, `dateCreate`) VALUES
(1,	'admin',	'$2y$13$ArLAzOtWEgnMbK2FEhsSa.NrcbCg9FXtaGvmAownBd4RVon5hEEOO',	'',	NULL,	NULL),
(2,	'manager',	'$2y$13$0RmhBJluvaJ5ImW6yzPQ0eGvppuQ3NzwirgjxWPNffGeKYWXOIWgW',	'\0s',	NULL,	NULL),
(33,	'vodyanov.ivan@yandex.ru',	'$2y$13$4U2Xasj0BbeF3Uu0t2nyrubmGONBluLR6TEXv2ukzCbSr31gtQ7nS',	'P',	NULL,	NULL),
(40,	'viadeveloper@gmail.com',	'$2y$13$Q5ZZ4E.9WtlK9lMlzrNpXOAtOv5JRd/9yW3VJ8k9vXJelUsfWeZ3K',	'\Z2',	NULL,	'2015-07-03 11:45:52'),
(41,	'x_vans_x@mail.ru',	'$2y$13$2TaZlTVBy6m0wTBCudFsDu8TYQEBsdbFmvmNRnmeqVzQ1To0ujXvK',	'',	NULL,	'2015-07-03 11:46:31');

DROP TABLE IF EXISTS `iv_user_balance_history`;
CREATE TABLE `iv_user_balance_history` (
  `id` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL COMMENT 'Пользователь',
  `type` smallint(6) NOT NULL COMMENT 'Тип операции',
  `sum` decimal(20,2) NOT NULL COMMENT 'Сумма',
  `date` datetime NOT NULL COMMENT 'Дата и время',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_balance_history` (`id`, `userId`, `type`, `sum`, `date`) VALUES
('b2330fc4531de135266de49078c270dd',	33,	1,	1000.00,	'2015-07-03 11:46:31'),
('c0c783b5fc0d7d808f1d14a6e9c8280d',	33,	1,	1000.00,	'2015-07-03 11:45:52'),
('d8e957bd2da1e36a73234faefd0547b3',	33,	2,	100.00,	'2015-07-03 11:51:51');

DROP TABLE IF EXISTS `iv_user_partner`;
CREATE TABLE `iv_user_partner` (
  `userId` int(11) NOT NULL COMMENT 'Пользователь',
  `partnerId` int(11) NOT NULL COMMENT 'Партнер',
  KEY `unique` (`userId`,`partnerId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_partner` (`userId`, `partnerId`) VALUES
(40,	33),
(41,	33);

DROP TABLE IF EXISTS `iv_user_profile`;
CREATE TABLE `iv_user_profile` (
  `userId` int(11) NOT NULL AUTO_INCREMENT,
  `phone` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `cityId` int(11) DEFAULT NULL,
  `photo` varchar(255) NOT NULL,
  `balance` decimal(20,2) DEFAULT '0.00' COMMENT 'Баланс',
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `iv_user_profile` (`userId`, `phone`, `name`, `cityId`, `photo`, `balance`) VALUES
(1,	'+998909124218',	'Водянов Иван',	2,	'',	0.00),
(33,	'+998712962849',	'Водянов Иван Александрович',	3,	'',	1900.00),
(40,	'+998712962849',	'Водянов Иван Александрович',	1,	'',	0.00),
(41,	'+998909124218',	'ViaDeveloper',	3,	'',	0.00);

DROP TABLE IF EXISTS `iv_user_pyramid`;
CREATE TABLE `iv_user_pyramid` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parentId` int(11) DEFAULT NULL,
  `type` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ixParentId` (`parentId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2015-08-15 06:14:53
